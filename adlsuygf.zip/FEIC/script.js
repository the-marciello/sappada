const fieldset = document.querySelector("fieldset")
const btnFieldset = document.querySelector("#btnFieldset")
const imgBtnFieldset = document.querySelector("#btnFieldset img")

let visibile = false
function setFieldset() {
    if(visibile)
    {
        fieldset.style.display = "none"
        imgBtnFieldset.src = "img/visibilita-on.png"
        imgBtnFieldset.alt = "Visibilita on"
    }
    else
    {
        fieldset.style.display = "block"
        imgBtnFieldset.src = "img/visibilita-off.png"
        imgBtnFieldset.alt = "Visibilita off"
    }
        
    visibile = !visibile
}

btnFieldset.style.margin = "10px auto 0 auto"
btnFieldset.addEventListener("click",setFieldset)